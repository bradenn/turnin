#include <iostream>

using namespace std;

int main(){
int a = 0;
while(cin >> a){
cout << "Hello, World! " << a << endl;
cerr << "Hello, World! " << a - 10 << endl;
}

return 0;
}
